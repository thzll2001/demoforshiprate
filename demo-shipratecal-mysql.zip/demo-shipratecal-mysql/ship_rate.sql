﻿# Host: localhost  (Version: 5.7.26)
# Date: 2021-08-10 15:33:38
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "ship_rate"
#

DROP TABLE IF EXISTS `ship_rate`;
CREATE TABLE `ship_rate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `province` varchar(255) DEFAULT NULL,
  `rate` double NOT NULL,
  `shipmethod` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# Data for table "ship_rate"
#

INSERT INTO `ship_rate` VALUES (1,'AB',6,'CP'),(2,'AB',5,'DHL');
INSERT INTO `ship_rate` VALUES (3,'BC',7,'CP');
INSERT INTO `ship_rate` VALUES (5,'ON',8,'CP'),(6,'ON',7.5,'DHL'),(7,'ON',6.8,'Fex');
INSERT INTO `ship_rate` VALUES (8,'QC',10,'CP'),(9,'ON',7.8,'Fex');

