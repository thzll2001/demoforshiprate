package com.demo.shipratecal;

import com.demo.shipratecal.Dao.ShipRateDao;
import com.demo.shipratecal.entity.ShipRate;
import com.demo.shipratecal.service.ShipRateCalService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;

import static org.assertj.core.api.Assertions.as;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.internal.bytebuddy.matcher.ElementMatchers.is;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ShipRateServiceTest {

    @Resource
    private ShipRateDao shipRateDao;

    @Resource
    private ShipRateCalService shipRateCalService;

    @Test
    public void shipRateCrudTest(){
        ShipRate shipRate = new ShipRate();
        shipRate.setProvince("TESTABC");
        shipRate.setRate(6.0);
        shipRate.setShipmethod("CP");
        ShipRate save = shipRateDao.save(shipRate) ;

        assertThat(shipRate.getId()).isEqualTo(save.getId());

        ShipRate updateShipRate =shipRateDao.findByProvince("TESTABC").get(0) ;
        updateShipRate.setProvince("TESTABC2");
        shipRate.setRate(6.0);
        shipRate.setShipmethod("CP");
        ShipRate save2 = shipRateDao.save(updateShipRate) ;

        List<ShipRate> result = shipRateDao.findByProvince("TESTABC2") ;

        assertThat( result.get(0).getProvince()).isEqualTo("TESTABC2");

        shipRateDao.delete(save2);
        shipRateDao.delete(shipRate);
        List<ShipRate> delResult = shipRateDao.findByProvince("TESTABC2") ;
        assertThat(delResult.isEmpty());

    }


    @Test
    public void shipRateServiceTest(){

        List<Double> ls =shipRateCalService.getProvinceRates("AB");
        assertThat(ls.get(0)).isEqualTo(new Double(6.0));
        assertThat(ls.get(1)).isEqualTo(new Double(5.0));
        assertThat(shipRateCalService.getProvinceMinRates("AB")).isEqualTo(new Double(5.0));
        shipRateCalService.updateRate("ON","CP", 8.8) ;
    }

}