package com.demo.shipratecal.service;

import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

public interface ShipRateCalService {
    public List<Double> getProvinceRates( String province) ;
    public double getProvinceMinRates( String province);
    public String updateRate(String province,String method,double rate);
}
