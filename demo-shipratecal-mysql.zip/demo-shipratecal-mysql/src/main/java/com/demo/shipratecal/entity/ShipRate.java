package com.demo.shipratecal.entity;

import javax.persistence.*;
import java.io.Serializable;


@Entity
//@Table(name="ship_rate")  // 和实体类中的哪个表对应
public class ShipRate implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    private String province;


    private Double rate;

    private String shipmethod;

    public ShipRate() {
    }

    public ShipRate(Long id, String province, Double rate, String shipmethod) {
        this.id = id;
        this.province = province;
        this.rate = rate;
        this.shipmethod = shipmethod;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    public String getShipmethod() {
        return shipmethod;
    }

    public void setShipmethod(String shipmethod) {
        this.shipmethod = shipmethod;
    }

    @Override
    public String toString() {
        return "ShipRate{" +
                "id=" + id +
                ", province='" + province + '\'' +
                ", rate=" + rate +
                ", shipmethod='" + shipmethod + '\'' +
                '}';
    }
}