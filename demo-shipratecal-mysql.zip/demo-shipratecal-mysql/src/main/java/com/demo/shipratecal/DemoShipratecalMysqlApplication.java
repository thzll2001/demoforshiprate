package com.demo.shipratecal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoShipratecalMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoShipratecalMysqlApplication.class, args);
	}

}
