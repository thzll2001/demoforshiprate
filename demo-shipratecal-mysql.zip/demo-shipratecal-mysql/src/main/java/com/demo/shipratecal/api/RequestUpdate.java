package com.demo.shipratecal.api;

import org.springframework.web.bind.annotation.RequestParam;

public class RequestUpdate {
   public String province;
   public String method;
   public double rate;

   public String getProvince() {
      return province;
   }

   public void setProvince(String province) {
      this.province = province;
   }

   public String getMethod() {
      return method;
   }

   public void setMethod(String method) {
      this.method = method;
   }

   public double getRate() {
      return rate;
   }

   public void setRate(double rate) {
      this.rate = rate;
   }
}
