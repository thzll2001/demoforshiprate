package com.demo.shipratecal.api;


import com.demo.shipratecal.service.ShipRateCalService;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

import java.util.List;


@RestController
public class IndexController {


    @Resource
    private ShipRateCalService shipRateCalService ;

    @RequestMapping("/")
    @ResponseBody
    public String index(){
        return "hello, the api is: /getProvinceRates,/getProvinceMinRates,/getProvinceMinRates,/updateRate";
    }
    @RequestMapping("/getProvinceRates")
    @ResponseBody
    public List<Double> getProvinceRates(@RequestParam String province){
        return shipRateCalService.getProvinceRates(province);
    }
    @RequestMapping("/getProvinceMinRates")
    @ResponseBody
    public  double getProvinceMinRates(@RequestParam String province){

        return shipRateCalService.getProvinceMinRates(province);
    }

    @RequestMapping(
            value = "/updateRate",
            method = RequestMethod.POST,
            produces = { "application/json"})
    @ResponseBody
    public String updateRate(@RequestBody  String  payload)
            throws Exception {
//curl  -H "Accept: application/json" -H "Content-type: application/json" -X POST  -d "{\"province\":\"ON\", \"method\":\"CP\",\"rate\":8.8}"  http://localhost:8080/updateRate
        System.out.println("payload:"+payload);
        ObjectMapper objectMapper = new ObjectMapper();
        RequestUpdate requestUpdate = objectMapper.readValue(payload, RequestUpdate.class);

        System.out.println(requestUpdate.method);
        System.out.println(requestUpdate.province);
        return shipRateCalService.updateRate(requestUpdate.province, requestUpdate.method, requestUpdate.rate);

    }
}