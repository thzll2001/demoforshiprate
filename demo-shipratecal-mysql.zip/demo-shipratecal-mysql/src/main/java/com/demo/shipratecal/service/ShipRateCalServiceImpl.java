package com.demo.shipratecal.service;

import com.demo.shipratecal.Dao.ShipRateDao;
import com.demo.shipratecal.entity.ShipRate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class ShipRateCalServiceImpl implements ShipRateCalService {
    @Autowired
    private ShipRateDao shipRateDao;

    @Override
    public List<Double> getProvinceRates(String province) {
       List<ShipRate> shipRates =  shipRateDao.findByProvince(province);
       List<Double> result  = new ArrayList<>() ;
       for(ShipRate shipRate :shipRates)
       {
           result.add(shipRate.getRate());
       }
       return result ;

    }

    @Override
    public double  getProvinceMinRates(String province) {


        double rate = shipRateDao.findTopByProvinceOrderByRate(province).getRate();

        return rate;

    }

    @Override
    public String updateRate(String province, String method, double rate) {
        try {
            List<ShipRate> shipRates = shipRateDao.findByProvince(province);
            for (ShipRate shipRate : shipRates) {
                if ( shipRate.getShipmethod().equals(method)) {
                    shipRate.setRate(rate);
                    shipRateDao.save(shipRate);
                }
            }
        }catch(Exception e){
           return "error" +e.getMessage();
        }
        return "success";
    }

}
