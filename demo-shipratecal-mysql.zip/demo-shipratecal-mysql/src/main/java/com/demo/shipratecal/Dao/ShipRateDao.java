package com.demo.shipratecal.Dao;

import com.demo.shipratecal.entity.ShipRate;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ShipRateDao extends CrudRepository<ShipRate, Long> {
    public List<ShipRate> findByProvince(String province);
    public ShipRate findTopByProvinceOrderByRate(String province);

}